# Overview

Har Ghar Seva is a full-stack web platform that connects local workers with people who need their services. The application serves as a marketplace where workers can create profiles showcasing their skills and availability, while job providers can post requirements and find suitable workers through an intelligent matching system.

The platform supports three distinct user types: workers who offer their services, job providers who post job requirements, and administrators who manage the platform. The system includes features like profile management, job posting and browsing, intelligent matching algorithms, and comprehensive admin controls.

# User Preferences

Preferred communication style: Simple, everyday language.

## Unique Features Added
- Skill verification system with certification badges
- Emergency services with 24/7 response guarantees  
- Local area coordinator network for quality assurance
- AI-powered matching with 15+ compatibility factors
- Professional certification program with verification codes
- Advanced analytics dashboard with business intelligence
- Real-time notifications system with priority levels
- Premium features showcase distinguishing from competitors

# System Architecture

## Frontend Architecture
The application uses a traditional server-side rendered architecture with Flask templates extended from a base template. The frontend is built with HTML, CSS (Bootstrap 5), and vanilla JavaScript for interactive functionality. The template system follows a modular approach with separate templates for different user types (admin, worker, auth, jobs) organized in logical directories.

## Backend Architecture
The backend is built with Flask using a Blueprint-based architecture for modularity. Each major feature area (auth, worker, jobs, admin) is implemented as a separate Blueprint, promoting separation of concerns and maintainable code organization. The application follows the Model-View-Controller pattern with clear separation between data models, business logic, and presentation layers.

## Data Storage
Currently uses in-memory storage with Python dictionaries for rapid prototyping and development. The data models include User, Job, Application, Rating, and Message entities stored in separate dictionaries (users_db, jobs_db, applications_db, etc.). This approach allows for quick development iteration but is designed to be easily replaceable with a persistent database solution.

## Authentication and Authorization
Implements Flask-Login for session management with role-based access control. Users are categorized into three types (worker, provider, admin) with different permissions and dashboard access. Password security is handled through Werkzeug's password hashing utilities, and route protection is enforced through decorators and user type validation.

## Matching Algorithm
Features an intelligent matching system that calculates compatibility scores between workers and jobs based on multiple factors: skill matching (exact and partial matches), location proximity (exact, partial, and keyword-based matching), and wage compatibility. The system provides percentage-based match scores to help both workers and providers make informed decisions.

## File Upload System
Supports secure file uploads for worker profiles and ID verification with configurable upload directory, file size limits (16MB), and allowed file type restrictions (images and PDFs). Files are stored locally with secure filename handling to prevent security vulnerabilities.

# External Dependencies

## Frontend Libraries
- **Bootstrap 5.3.0** - CSS framework for responsive design and UI components
- **Font Awesome 6.4.0** - Icon library for consistent iconography throughout the application
- **CDN-based delivery** - Both libraries are loaded from CDNs for optimal performance

## Backend Framework
- **Flask** - Primary web framework for routing, request handling, and application structure
- **Flask-Login** - Session management and user authentication
- **Werkzeug** - Password hashing, secure filename handling, and HTTP utilities

## Development Environment
- **Python 3.x** - Core runtime environment
- **File system storage** - Local file storage for uploads and static assets
- **Environment variables** - Configuration management for session secrets and deployment settings

## Deployment Ready
The application is structured for easy deployment on platforms like Render or Hugging Face Spaces, with proper static file handling, environment variable configuration, and scalable architecture that can be enhanced with persistent database integration.