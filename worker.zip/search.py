from flask import Blueprint, render_template, request, jsonify
from flask_login import current_user
from models import users_db, jobs_db
import re

search_bp = Blueprint('search', __name__)

@search_bp.route('/api/search')
def search_api():
    """Advanced search API endpoint"""
    query = request.args.get('q', '').strip()
    search_type = request.args.get('type', 'jobs')  # 'jobs' or 'workers'
    location = request.args.get('location', '')
    skills = request.args.get('skills', '')
    min_wage = request.args.get('min_wage', type=int)
    max_wage = request.args.get('max_wage', type=int)
    min_rating = request.args.get('min_rating', type=float)
    availability = request.args.get('availability')  # 'available' or 'all'
    
    if search_type == 'jobs':
        results = search_jobs(query, location, skills, min_wage, max_wage)
    else:
        results = search_workers(query, location, skills, min_wage, max_wage, min_rating, availability)
    
    return jsonify({
        'results': results,
        'total': len(results),
        'query': query,
        'type': search_type
    })

def search_jobs(query, location, skills, min_wage, max_wage):
    """Search for jobs with filters"""
    results = []
    
    for job in jobs_db.values():
        if job.status != 'open':
            continue
            
        score = 0
        matches = []
        
        # Text search in title and description
        if query:
            title_matches = len(re.findall(re.escape(query.lower()), job.title.lower()))
            desc_matches = len(re.findall(re.escape(query.lower()), job.description.lower()))
            
            if title_matches > 0:
                score += title_matches * 10
                matches.append(f"Title: {title_matches} matches")
            
            if desc_matches > 0:
                score += desc_matches * 5
                matches.append(f"Description: {desc_matches} matches")
        
        # Location filter
        if location and location.lower() not in job.location.lower():
            continue
            
        # Skills filter
        if skills:
            skill_list = [s.strip().lower() for s in skills.split(',')]
            job_skills = [s.lower() for s in (job.skills_required or [])]
            
            matching_skills = set(skill_list) & set(job_skills)
            if matching_skills:
                score += len(matching_skills) * 15
                matches.append(f"Skills: {', '.join(matching_skills)}")
            elif skills:  # If skills specified but none match
                continue
        
        # Wage filter
        if min_wage and job.wage_offer < min_wage:
            continue
        if max_wage and job.wage_offer > max_wage:
            continue
            
        # If no query, give base score
        if not query:
            score = 10
        
        # Skip if no matches and query was provided
        if query and score == 0:
            continue
            
        # Get provider info
        provider = users_db.get(job.provider_id)
        
        results.append({
            'id': job.id,
            'title': job.title,
            'description': job.description[:150] + '...' if len(job.description) > 150 else job.description,
            'location': job.location,
            'wage_offer': job.wage_offer,
            'skills_required': job.skills_required,
            'provider_name': provider.username if provider else 'Unknown',
            'posted_date': job.created_at.strftime('%Y-%m-%d'),
            'score': score,
            'matches': matches,
            'url': f"/jobs/details/{job.id}"
        })
    
    # Sort by relevance score
    results.sort(key=lambda x: x['score'], reverse=True)
    
    return results

def search_workers(query, location, skills, min_wage, max_wage, min_rating, availability):
    """Search for workers with filters"""
    results = []
    
    for worker in users_db.values():
        if worker.user_type != 'worker':
            continue
            
        # Availability filter
        if availability == 'available' and not worker.is_available:
            continue
            
        score = 0
        matches = []
        
        # Text search in username and bio
        if query:
            name_matches = len(re.findall(re.escape(query.lower()), worker.username.lower()))
            
            if name_matches > 0:
                score += name_matches * 10
                matches.append(f"Name: {name_matches} matches")
        
        # Location filter
        if location and location.lower() not in (worker.location or '').lower():
            continue
            
        # Skills filter
        if skills:
            skill_list = [s.strip().lower() for s in skills.split(',')]
            worker_skills = [s.lower() for s in (worker.skills or [])]
            
            matching_skills = set(skill_list) & set(worker_skills)
            if matching_skills:
                score += len(matching_skills) * 15
                matches.append(f"Skills: {', '.join(matching_skills)}")
            elif skills:  # If skills specified but none match
                continue
        
        # Wage filter
        if min_wage and (worker.hourly_wage or 0) < min_wage:
            continue
        if max_wage and (worker.hourly_wage or 0) > max_wage:
            continue
            
        # Rating filter
        if min_rating and (worker.rating or 0) < min_rating:
            continue
        
        # If no query, give base score
        if not query:
            score = 10
        
        # Skip if no matches and query was provided
        if query and score == 0:
            continue
            
        results.append({
            'id': worker.id,
            'username': worker.username,
            'location': worker.location,
            'skills': worker.skills,
            'hourly_wage': worker.hourly_wage,
            'experience_years': worker.experience_years,
            'rating': worker.rating or 0,
            'rating_count': worker.rating_count or 0,
            'is_available': worker.is_available,
            'is_verified': worker.is_verified,
            'profile_photo': worker.profile_photo,
            'score': score,
            'matches': matches,
            'url': f"/worker/profile/{worker.id}"
        })
    
    # Sort by relevance score, then by rating
    results.sort(key=lambda x: (x['score'], x['rating']), reverse=True)
    
    return results

@search_bp.route('/search')
def search_page():
    """Advanced search page"""
    search_type = request.args.get('type', 'jobs')
    return render_template('search/advanced_search.html', search_type=search_type)

@search_bp.route('/api/suggestions')
def search_suggestions():
    """Get search suggestions"""
    query = request.args.get('q', '').strip().lower()
    search_type = request.args.get('type', 'jobs')
    
    suggestions = []
    
    if len(query) >= 2:  # Minimum 2 characters
        if search_type == 'jobs':
            # Job title suggestions
            job_titles = set()
            for job in jobs_db.values():
                if query in job.title.lower():
                    job_titles.add(job.title)
            suggestions.extend(list(job_titles)[:5])
            
            # Skill suggestions from job requirements
            skills = set()
            for job in jobs_db.values():
                if job.skills_required:
                    for skill in job.skills_required:
                        if query in skill.lower():
                            skills.add(skill)
            suggestions.extend(list(skills)[:3])
            
        else:  # Workers
            # Username suggestions
            usernames = set()
            for worker in users_db.values():
                if worker.user_type == 'worker' and query in worker.username.lower():
                    usernames.add(worker.username)
            suggestions.extend(list(usernames)[:5])
            
            # Skill suggestions from worker profiles
            skills = set()
            for worker in users_db.values():
                if worker.user_type == 'worker' and worker.skills:
                    for skill in worker.skills:
                        if query in skill.lower():
                            skills.add(skill)
            suggestions.extend(list(skills)[:3])
    
    return jsonify({'suggestions': suggestions[:8]})  # Limit to 8 suggestions

def get_popular_searches():
    """Get popular search terms"""
    # In a real app, this would be based on search analytics
    popular_jobs = ['Plumber', 'Electrician', 'Carpenter', 'Cleaner', 'Cook']
    popular_skills = ['Plumbing', 'Electrical', 'Carpentry', 'Cleaning', 'Cooking']
    
    return {
        'jobs': popular_jobs,
        'skills': popular_skills
    }