from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import create_job, get_jobs_by_provider, get_open_jobs, jobs_db, apply_for_job, applications_db, users_db
from matching import find_matching_workers

jobs_bp = Blueprint('jobs', __name__)

@jobs_bp.route('/browse')
def browse():
    search = request.args.get('search', '')
    location = request.args.get('location', '')
    min_wage = request.args.get('min_wage', '')
    skill = request.args.get('skill', '')
    
    jobs = get_open_jobs()
    
    # Apply filters
    if search:
        jobs = [job for job in jobs if search.lower() in job.title.lower() or 
                search.lower() in job.description.lower()]
    
    if location:
        jobs = [job for job in jobs if location.lower() in job.location.lower()]
    
    if min_wage:
        try:
            min_wage_float = float(min_wage)
            jobs = [job for job in jobs if job.wage_offer >= min_wage_float]
        except ValueError:
            pass
    
    if skill:
        jobs = [job for job in jobs if any(skill.lower() in s.lower() for s in job.skills_required)]
    
    return render_template('jobs/browse.html', jobs=jobs, 
                         search=search, location=location, min_wage=min_wage, skill=skill)

@jobs_bp.route('/post', methods=['GET', 'POST'])
@login_required
def post():
    if current_user.user_type not in ['provider', 'admin']:
        flash('Only job providers can post jobs.', 'error')
        return redirect(url_for('jobs.browse'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        skills_required = request.form.get('skills_required', '')
        location = request.form.get('location')
        duration = request.form.get('duration')
        wage_offer = request.form.get('wage_offer')
        contact_details = request.form.get('contact_details')
        
        # Validation
        if not all([title, description, location, duration, wage_offer]):
            flash('All fields are required.', 'error')
            return render_template('jobs/post.html')
        
        try:
            wage_offer = float(wage_offer)
        except ValueError:
            flash('Invalid wage amount.', 'error')
            return render_template('jobs/post.html')
        
        # Parse skills
        skills_list = [skill.strip() for skill in skills_required.split(',') if skill.strip()]
        
        # Create job
        job = create_job(current_user.id, title, description, skills_list, 
                        location, duration, wage_offer, contact_details)
        
        flash('Job posted successfully!', 'success')
        return redirect(url_for('jobs.details', job_id=job.id))
    
    return render_template('jobs/post.html')

@jobs_bp.route('/details/<int:job_id>')
def details(job_id):
    job = jobs_db.get(job_id)
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('jobs.browse'))
    
    provider = users_db.get(job.provider_id)
    matching_workers = []
    
    # Show matching workers if user is the job provider
    if current_user.is_authenticated and current_user.id == job.provider_id:
        matching_workers = find_matching_workers(job_id)
    
    # Check if current user has already applied
    has_applied = False
    if current_user.is_authenticated and current_user.user_type == 'worker':
        has_applied = any(app.worker_id == current_user.id for app in applications_db.values() 
                         if app.job_id == job_id)
    
    return render_template('jobs/details.html', job=job, provider=provider, 
                         matching_workers=matching_workers, has_applied=has_applied)

@jobs_bp.route('/apply/<int:job_id>', methods=['POST'])
@login_required
def apply(job_id):
    if current_user.user_type != 'worker':
        flash('Only workers can apply for jobs.', 'error')
        return redirect(url_for('jobs.details', job_id=job_id))
    
    if not current_user.is_verified:
        flash('Please wait for admin verification before applying for jobs.', 'error')
        return redirect(url_for('jobs.details', job_id=job_id))
    
    job = jobs_db.get(job_id)
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('jobs.browse'))
    
    # Check if already applied
    has_applied = any(app.worker_id == current_user.id for app in applications_db.values() 
                     if app.job_id == job_id)
    
    if has_applied:
        flash('You have already applied for this job.', 'error')
        return redirect(url_for('jobs.details', job_id=job_id))
    
    message = request.form.get('message', '')
    apply_for_job(job_id, current_user.id, message)
    
    flash('Application submitted successfully!', 'success')
    return redirect(url_for('jobs.details', job_id=job_id))

@jobs_bp.route('/my_jobs')
@login_required
def my_jobs():
    if current_user.user_type not in ['provider', 'admin']:
        flash('Access denied.', 'error')
        return redirect(url_for('jobs.browse'))
    
    jobs = get_jobs_by_provider(current_user.id)
    
    # Get applications for each job
    for job in jobs:
        job.applications_data = []
        for app_id in job.applications:
            app = applications_db.get(app_id)
            if app:
                worker = users_db.get(app.worker_id)
                job.applications_data.append({
                    'application': app,
                    'worker': worker
                })
    
    return render_template('jobs/my_jobs.html', jobs=jobs)
