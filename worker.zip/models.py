from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import uuid

# In-memory storage for MVP
users_db = {}
jobs_db = {}
applications_db = {}
ratings_db = {}
messages_db = {}
conversations_db = {}

class User(UserMixin):
    def __init__(self, username, email, password, user_type='worker'):
        self.id = len(users_db) + 1
        self.username = username
        self.email = email
        self.password_hash = generate_password_hash(password)
        self.user_type = user_type  # 'worker', 'provider', 'admin'
        self.created_at = datetime.now()
        self.is_verified = user_type == 'admin'  # Admin auto-verified
        self.is_available = True
        
        # Worker specific fields
        if user_type == 'worker':
            self.skills = []
            self.experience_years = 0
            self.hourly_wage = 0
            self.location = ''
            self.phone = ''
            self.bio = ''
            self.profile_photo = None
            self.id_proof = None
            self.rating = 0.0
            self.total_jobs = 0

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return str(self.id)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'user_type': self.user_type,
            'is_verified': self.is_verified,
            'is_available': self.is_available,
            'created_at': self.created_at.isoformat()
        }

class Job:
    def __init__(self, provider_id, title, description, skills_required, location, 
                 duration, wage_offer, contact_details):
        self.id = len(jobs_db) + 1
        self.provider_id = provider_id
        self.title = title
        self.description = description
        self.skills_required = skills_required  # List of skills
        self.location = location
        self.duration = duration
        self.wage_offer = wage_offer
        self.contact_details = contact_details
        self.status = 'open'  # 'open', 'assigned', 'completed', 'cancelled'
        self.created_at = datetime.now()
        self.applications = []

    def to_dict(self):
        return {
            'id': self.id,
            'provider_id': self.provider_id,
            'title': self.title,
            'description': self.description,
            'skills_required': self.skills_required,
            'location': self.location,
            'duration': self.duration,
            'wage_offer': self.wage_offer,
            'contact_details': self.contact_details,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'applications_count': len(self.applications)
        }

class Application:
    def __init__(self, job_id, worker_id, message=''):
        self.id = len(applications_db) + 1
        self.job_id = job_id
        self.worker_id = worker_id
        self.message = message
        self.status = 'pending'  # 'pending', 'accepted', 'rejected'
        self.created_at = datetime.now()

class Rating:
    def __init__(self, job_id, rater_id, rated_id, rating, review=''):
        self.id = len(ratings_db) + 1
        self.job_id = job_id
        self.rater_id = rater_id
        self.rated_id = rated_id
        self.rating = rating  # 1-5 stars
        self.review = review
        self.created_at = datetime.now()

class Message:
    def __init__(self, sender_id, recipient_id, message, job_id=None):
        self.id = len(messages_db) + 1
        self.sender_id = sender_id
        self.recipient_id = recipient_id
        self.message = message
        self.job_id = job_id  # Optional: link to specific job
        self.is_read = False
        self.created_at = datetime.now()
        self.conversation_id = f"{min(sender_id, recipient_id)}-{max(sender_id, recipient_id)}"

# Helper functions
def create_user(username, email, password, user_type='worker'):
    user = User(username, email, password, user_type)
    users_db[user.id] = user
    return user

def get_user_by_email(email):
    for user in users_db.values():
        if user.email == email:
            return user
    return None

def get_user_by_username(username):
    for user in users_db.values():
        if user.username == username:
            return user
    return None

def create_job(provider_id, title, description, skills_required, location, 
               duration, wage_offer, contact_details):
    job = Job(provider_id, title, description, skills_required, location, 
              duration, wage_offer, contact_details)
    jobs_db[job.id] = job
    return job

def get_jobs_by_provider(provider_id):
    return [job for job in jobs_db.values() if job.provider_id == provider_id]

def get_open_jobs():
    return [job for job in jobs_db.values() if job.status == 'open']

def apply_for_job(job_id, worker_id, message=''):
    application = Application(job_id, worker_id, message)
    applications_db[application.id] = application
    
    # Add to job's applications list
    if job_id in jobs_db:
        jobs_db[job_id].applications.append(application.id)
    
    return application

def create_message(sender_id, recipient_id, message, job_id=None):
    msg = Message(sender_id, recipient_id, message, job_id)
    messages_db[msg.id] = msg
    return msg

def get_conversations(user_id):
    """Get all conversations for a user"""
    user_conversations = {}
    
    for message in messages_db.values():
        if message.sender_id == user_id or message.recipient_id == user_id:
            other_user_id = message.recipient_id if message.sender_id == user_id else message.sender_id
            conversation_id = message.conversation_id
            
            if conversation_id not in user_conversations:
                other_user = users_db.get(other_user_id)
                user_conversations[conversation_id] = {
                    'other_user': other_user,
                    'last_message': message,
                    'unread_count': 0
                }
            else:
                # Update with latest message
                if message.created_at > user_conversations[conversation_id]['last_message'].created_at:
                    user_conversations[conversation_id]['last_message'] = message
            
            # Count unread messages
            if message.recipient_id == user_id and not message.is_read:
                user_conversations[conversation_id]['unread_count'] += 1
    
    # Sort by latest message time
    return sorted(user_conversations.values(), 
                  key=lambda x: x['last_message'].created_at, 
                  reverse=True)

def get_messages_by_conversation(conversation_id):
    """Get all messages in a conversation"""
    messages = [msg for msg in messages_db.values() 
                if msg.conversation_id == conversation_id]
    return sorted(messages, key=lambda x: x.created_at)

def get_unread_count(user_id):
    """Get total unread message count for a user"""
    return len([msg for msg in messages_db.values() 
                if msg.recipient_id == user_id and not msg.is_read])

def create_rating(job_id, rater_id, rated_id, rating, review=''):
    """Create a new rating"""
    rating_obj = Rating(job_id, rater_id, rated_id, rating, review)
    ratings_db[rating_obj.id] = rating_obj
    return rating_obj

def get_ratings_for_user(user_id):
    """Get all ratings for a specific user"""
    return [rating for rating in ratings_db.values() if rating.rated_id == user_id]

def get_applications(job_id):
    """Get all applications for a specific job"""
    return [app for app in applications_db.values() if app.job_id == job_id]

# Create default admin user
if not users_db:
    admin = create_user('admin', 'admin@hargharseva.com', 'admin123', 'admin')
    admin.is_verified = True
