from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import (create_rating, users_db, jobs_db, ratings_db, 
                   applications_db, get_applications, get_ratings_for_user)

ratings_bp = Blueprint('ratings', __name__)

@ratings_bp.route('/rate/<int:job_id>/<int:rated_user_id>')
@login_required
def rate_user(job_id, rated_user_id):
    """Show rating form for a user after job completion"""
    job = jobs_db.get(job_id)
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('jobs.browse'))
    
    rated_user = users_db.get(rated_user_id)
    if not rated_user:
        flash('User not found.', 'error')
        return redirect(url_for('jobs.browse'))
    
    # Check if current user can rate this user for this job
    can_rate = False
    
    # Job provider can rate workers who applied
    if current_user.id == job.provider_id and rated_user.user_type == 'worker':
        applications = get_applications(job_id)
        worker_applied = any(app.worker_id == rated_user_id for app in applications)
        can_rate = worker_applied
    
    # Worker can rate job provider if they applied
    elif current_user.user_type == 'worker' and rated_user.id == job.provider_id:
        applications = get_applications(job_id)
        current_user_applied = any(app.worker_id == current_user.id for app in applications)
        can_rate = current_user_applied
    
    if not can_rate:
        flash('You can only rate users you have worked with.', 'error')
        return redirect(url_for('jobs.details', job_id=job_id))
    
    # Check if already rated
    existing_rating = None
    for rating in ratings_db.values():
        if (rating.job_id == job_id and 
            rating.rater_id == current_user.id and 
            rating.rated_id == rated_user_id):
            existing_rating = rating
            break
    
    return render_template('ratings/rate_user.html', 
                         job=job, 
                         rated_user=rated_user, 
                         existing_rating=existing_rating)

@ratings_bp.route('/submit_rating', methods=['POST'])
@login_required
def submit_rating():
    """Submit a rating for a user"""
    job_id = int(request.form.get('job_id'))
    rated_user_id = int(request.form.get('rated_user_id'))
    rating = int(request.form.get('rating'))
    review = request.form.get('review', '').strip()
    
    # Validation
    if not (1 <= rating <= 5):
        flash('Rating must be between 1 and 5 stars.', 'error')
        return redirect(url_for('ratings.rate_user', job_id=job_id, rated_user_id=rated_user_id))
    
    job = jobs_db.get(job_id)
    rated_user = users_db.get(rated_user_id)
    
    if not job or not rated_user:
        flash('Invalid job or user.', 'error')
        return redirect(url_for('jobs.browse'))
    
    # Check if already rated
    for existing_rating in ratings_db.values():
        if (existing_rating.job_id == job_id and 
            existing_rating.rater_id == current_user.id and 
            existing_rating.rated_id == rated_user_id):
            # Update existing rating
            existing_rating.rating = rating
            existing_rating.review = review
            flash(f'Updated your rating for {rated_user.username}!', 'success')
            break
    else:
        # Create new rating
        create_rating(job_id, current_user.id, rated_user_id, rating, review)
        flash(f'Thank you for rating {rated_user.username}!', 'success')
    
    # Update user's average rating
    update_user_rating(rated_user_id)
    
    return redirect(url_for('jobs.details', job_id=job_id))

@ratings_bp.route('/user/<int:user_id>/reviews')
def user_reviews(user_id):
    """Display all reviews for a specific user"""
    user = users_db.get(user_id)
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('jobs.browse'))
    
    user_ratings = get_ratings_for_user(user_id)
    
    # Group ratings by star count for display
    rating_counts = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for rating in user_ratings:
        rating_counts[rating.rating] += 1
    
    return render_template('ratings/user_reviews.html', 
                         user=user, 
                         ratings=user_ratings, 
                         rating_counts=rating_counts)

@ratings_bp.route('/api/quick_rate', methods=['POST'])
@login_required
def api_quick_rate():
    """Quick rating API for AJAX calls"""
    try:
        data = request.get_json()
        job_id = int(data.get('job_id'))
        rated_user_id = int(data.get('rated_user_id'))
        rating = int(data.get('rating'))
        
        if not (1 <= rating <= 5):
            return jsonify({'success': False, 'error': 'Invalid rating'})
        
        # Check if already rated
        for existing_rating in ratings_db.values():
            if (existing_rating.job_id == job_id and 
                existing_rating.rater_id == current_user.id and 
                existing_rating.rated_id == rated_user_id):
                existing_rating.rating = rating
                update_user_rating(rated_user_id)
                return jsonify({'success': True, 'message': 'Rating updated'})
        
        # Create new rating
        create_rating(job_id, current_user.id, rated_user_id, rating)
        update_user_rating(rated_user_id)
        
        return jsonify({'success': True, 'message': 'Rating submitted'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def update_user_rating(user_id):
    """Update a user's average rating"""
    user = users_db.get(user_id)
    if not user:
        return
    
    user_ratings = get_ratings_for_user(user_id)
    
    if user_ratings:
        total_rating = sum(rating.rating for rating in user_ratings)
        average_rating = round(total_rating / len(user_ratings), 1)
        user.rating = average_rating
        user.rating_count = len(user_ratings)
    else:
        user.rating = 0
        user.rating_count = 0

def can_rate_user(rater_id, rated_user_id, job_id):
    """Check if a user can rate another user for a specific job"""
    job = jobs_db.get(job_id)
    if not job:
        return False
    
    rater = users_db.get(rater_id)
    rated_user = users_db.get(rated_user_id)
    
    if not rater or not rated_user:
        return False
    
    # Job provider can rate workers who applied
    if rater_id == job.provider_id and rated_user.user_type == 'worker':
        applications = get_applications(job_id)
        return any(app.worker_id == rated_user_id for app in applications)
    
    # Worker can rate job provider if they applied
    elif rater.user_type == 'worker' and rated_user_id == job.provider_id:
        applications = get_applications(job_id)
        return any(app.worker_id == rater_id for app in applications)
    
    return False