from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import os
from models import users_db, get_open_jobs
from matching import find_matching_jobs

worker_bp = Blueprint('worker', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@worker_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'worker':
        flash('Access denied.', 'error')
        return redirect(url_for('index'))
    
    # Get matching jobs
    matching_jobs = find_matching_jobs(current_user.id)
    
    return render_template('worker/dashboard.html', 
                         user=current_user, 
                         matching_jobs=matching_jobs)

@worker_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if current_user.user_type != 'worker':
        flash('Access denied.', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        # Update profile information
        current_user.phone = request.form.get('phone', '')
        current_user.location = request.form.get('location', '')
        current_user.bio = request.form.get('bio', '')
        current_user.experience_years = int(request.form.get('experience_years', 0))
        current_user.hourly_wage = float(request.form.get('hourly_wage', 0))
        current_user.is_available = 'is_available' in request.form
        
        # Handle skills (comma-separated)
        skills_input = request.form.get('skills', '')
        current_user.skills = [skill.strip() for skill in skills_input.split(',') if skill.strip()]
        
        # Handle file uploads
        if 'profile_photo' in request.files:
            file = request.files['profile_photo']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"profile_{current_user.id}_{file.filename}")
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                current_user.profile_photo = filename
        
        if 'id_proof' in request.files:
            file = request.files['id_proof']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"id_{current_user.id}_{file.filename}")
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                current_user.id_proof = filename
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('worker.profile'))
    
    return render_template('worker/profile.html', user=current_user)

@worker_bp.route('/toggle_availability')
@login_required
def toggle_availability():
    if current_user.user_type != 'worker':
        flash('Access denied.', 'error')
        return redirect(url_for('index'))
    
    current_user.is_available = not current_user.is_available
    status = "Available" if current_user.is_available else "Not Available"
    flash(f'Availability status updated to: {status}', 'success')
    
    return redirect(url_for('worker.dashboard'))
