from models import users_db, jobs_db

def calculate_skill_match(worker_skills, required_skills):
    """Calculate skill match percentage between worker and job"""
    if not required_skills:
        return 100  # If no specific skills required, everyone matches
    
    if not worker_skills:
        return 0  # Worker has no skills listed
    
    # Convert to lowercase for case-insensitive matching
    worker_skills_lower = [skill.lower().strip() for skill in worker_skills]
    required_skills_lower = [skill.lower().strip() for skill in required_skills]
    
    matched_skills = 0
    for required_skill in required_skills_lower:
        for worker_skill in worker_skills_lower:
            if required_skill in worker_skill or worker_skill in required_skill:
                matched_skills += 1
                break
    
    return min(100, (matched_skills / len(required_skills_lower)) * 100)

def calculate_location_match(worker_location, job_location):
    """Calculate location match percentage"""
    if not worker_location or not job_location:
        return 50  # Neutral score if location not specified
    
    worker_loc = worker_location.lower().strip()
    job_loc = job_location.lower().strip()
    
    if worker_loc == job_loc:
        return 100
    elif worker_loc in job_loc or job_loc in worker_loc:
        return 80
    else:
        # Check for common words (city names, areas)
        worker_words = set(worker_loc.split())
        job_words = set(job_loc.split())
        common_words = worker_words.intersection(job_words)
        
        if common_words:
            return 60
        else:
            return 20

def calculate_wage_match(worker_wage, job_wage):
    """Calculate wage compatibility percentage"""
    if worker_wage == 0 or job_wage == 0:
        return 50  # Neutral score if wage not specified
    
    if worker_wage <= job_wage:
        return 100  # Worker's expectation met or exceeded
    else:
        # Calculate how far off the job wage is from worker's expectation
        difference_ratio = (worker_wage - job_wage) / worker_wage
        if difference_ratio <= 0.1:  # Within 10%
            return 90
        elif difference_ratio <= 0.2:  # Within 20%
            return 70
        elif difference_ratio <= 0.3:  # Within 30%
            return 50
        else:
            return 20

def calculate_overall_match_score(worker, job):
    """Calculate overall match score between worker and job"""
    skill_match = calculate_skill_match(worker.skills, job.skills_required)
    location_match = calculate_location_match(worker.location, job.location)
    wage_match = calculate_wage_match(worker.hourly_wage, job.wage_offer)
    
    # Weighted average: skills (50%), location (30%), wage (20%)
    overall_score = (skill_match * 0.5) + (location_match * 0.3) + (wage_match * 0.2)
    
    return round(overall_score, 1)

def find_matching_jobs(worker_id, limit=5):
    """Find matching jobs for a worker"""
    worker = users_db.get(worker_id)
    if not worker or worker.user_type != 'worker' or not worker.is_available:
        return []
    
    open_jobs = [job for job in jobs_db.values() if job.status == 'open']
    
    job_matches = []
    for job in open_jobs:
        match_score = calculate_overall_match_score(worker, job)
        if match_score >= 20:  # Only include jobs with at least 20% match
            job_matches.append({
                'job': job,
                'match_score': match_score,
                'provider': users_db.get(job.provider_id)
            })
    
    # Sort by match score and return top matches
    job_matches.sort(key=lambda x: x['match_score'], reverse=True)
    return job_matches[:limit]

def find_matching_workers(job_id, limit=5):
    """Find matching workers for a job"""
    job = jobs_db.get(job_id)
    if not job:
        return []
    
    verified_workers = [worker for worker in users_db.values() 
                       if worker.user_type == 'worker' and worker.is_verified and worker.is_available]
    
    worker_matches = []
    for worker in verified_workers:
        match_score = calculate_overall_match_score(worker, job)
        if match_score >= 20:  # Only include workers with at least 20% match
            worker_matches.append({
                'worker': worker,
                'match_score': match_score
            })
    
    # Sort by match score and return top matches
    worker_matches.sort(key=lambda x: x['match_score'], reverse=True)
    return worker_matches[:limit]
