from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models import users_db, jobs_db, applications_db
from datetime import datetime, timedelta
import random
import hashlib

unique_bp = Blueprint('unique', __name__)

# Unique Feature 1: Skill Verification System
skill_tests_db = {}
skill_badges_db = {}

class SkillTest:
    def __init__(self, skill_name, questions):
        self.id = len(skill_tests_db) + 1
        self.skill_name = skill_name
        self.questions = questions
        self.created_at = datetime.now()

class SkillBadge:
    def __init__(self, user_id, skill_name, score, verified_at):
        self.id = len(skill_badges_db) + 1
        self.user_id = user_id
        self.skill_name = skill_name
        self.score = score
        self.verified_at = verified_at
        self.badge_level = self.get_badge_level(score)
    
    def get_badge_level(self, score):
        if score >= 90: return "Expert"
        elif score >= 75: return "Advanced"
        elif score >= 60: return "Intermediate"
        else: return "Beginner"

# Unique Feature 2: Local Area Coordinator System
coordinators_db = {}

class AreaCoordinator:
    def __init__(self, user_id, area, specializations):
        self.id = len(coordinators_db) + 1
        self.user_id = user_id
        self.area = area
        self.specializations = specializations
        self.verified_workers = []
        self.rating = 0
        self.total_coordinated = 0

# Unique Feature 3: Emergency Service System
emergency_services_db = {}

class EmergencyService:
    def __init__(self, provider_id, service_type, response_time, premium_rate):
        self.id = len(emergency_services_db) + 1
        self.provider_id = provider_id
        self.service_type = service_type
        self.response_time = response_time  # in minutes
        self.premium_rate = premium_rate
        self.available_24x7 = True
        self.emergency_contact = None

# Unique Feature 4: Worker Certification Program
certifications_db = {}

class WorkerCertification:
    def __init__(self, user_id, certification_type, issued_by, valid_until):
        self.id = len(certifications_db) + 1
        self.user_id = user_id
        self.certification_type = certification_type
        self.issued_by = issued_by
        self.issued_at = datetime.now()
        self.valid_until = valid_until
        self.verification_code = self.generate_verification_code()
    
    def generate_verification_code(self):
        data = f"{self.user_id}{self.certification_type}{self.issued_at}"
        return hashlib.md5(data.encode()).hexdigest()[:8].upper()

# Unique Feature 5: AI-Powered Job Matching
def calculate_unique_match_score(worker, job):
    """Advanced matching algorithm with unique factors"""
    score = 0
    
    # Basic skill matching (30%)
    if hasattr(worker, 'skills') and hasattr(job, 'skills_required'):
        worker_skills = set(s.lower() for s in (worker.skills or []))
        job_skills = set(s.lower() for s in (job.skills_required or []))
        skill_match = len(worker_skills & job_skills) / len(job_skills) if job_skills else 0
        score += skill_match * 30
    
    # Experience level matching (20%)
    if hasattr(worker, 'experience_years') and hasattr(job, 'experience_required'):
        exp_diff = abs((worker.experience_years or 0) - (job.experience_required or 0))
        exp_score = max(0, 20 - exp_diff * 2)
        score += exp_score
    
    # Location proximity (15%)
    if hasattr(worker, 'location') and hasattr(job, 'location'):
        if (worker.location or '').lower() == (job.location or '').lower():
            score += 15
        elif any(word in (worker.location or '').lower() for word in (job.location or '').lower().split()):
            score += 10
    
    # Availability matching (10%)
    if hasattr(worker, 'is_available') and worker.is_available:
        score += 10
    
    # Rating bonus (10%)
    if hasattr(worker, 'rating') and worker.rating:
        score += (worker.rating / 5) * 10
    
    # Certification bonus (10%)
    worker_certs = [cert for cert in certifications_db.values() if cert.user_id == worker.id]
    if worker_certs:
        score += min(len(worker_certs) * 2, 10)
    
    # Emergency service bonus (5%)
    emergency_services = [es for es in emergency_services_db.values() if es.provider_id == worker.id]
    if emergency_services:
        score += 5
    
    return min(score, 100)

@unique_bp.route('/skill-verification')
@login_required
def skill_verification():
    """Skill verification dashboard"""
    if current_user.user_type != 'worker':
        flash('Only workers can access skill verification', 'error')
        return redirect(url_for('index'))
    
    available_tests = [
        {'skill': 'Plumbing', 'duration': '30 min', 'questions': 20},
        {'skill': 'Electrical', 'duration': '45 min', 'questions': 25},
        {'skill': 'Carpentry', 'duration': '35 min', 'questions': 22},
        {'skill': 'Cleaning', 'duration': '20 min', 'questions': 15},
        {'skill': 'Cooking', 'duration': '40 min', 'questions': 25}
    ]
    
    user_badges = [badge for badge in skill_badges_db.values() if badge.user_id == current_user.id]
    
    return render_template('unique/skill_verification.html', 
                         available_tests=available_tests, 
                         user_badges=user_badges)

@unique_bp.route('/take-skill-test/<skill>')
@login_required
def take_skill_test(skill):
    """Take a skill verification test"""
    # Sample questions for demonstration
    questions = {
        'Plumbing': [
            {'q': 'What is the standard diameter for main water supply pipes?', 'options': ['1 inch', '1.5 inch', '2 inch', '0.75 inch'], 'correct': 0},
            {'q': 'Which tool is essential for pipe threading?', 'options': ['Hacksaw', 'Pipe die', 'Wrench', 'Hammer'], 'correct': 1},
            {'q': 'What should you do before starting any plumbing work?', 'options': ['Turn off electricity', 'Turn off main water supply', 'Call supervisor', 'Check weather'], 'correct': 1}
        ],
        'Electrical': [
            {'q': 'What voltage is standard for household electricity in India?', 'options': ['110V', '220V', '240V', '120V'], 'correct': 1},
            {'q': 'Which safety device protects against electrical overload?', 'options': ['Fuse', 'Switch', 'Wire', 'Outlet'], 'correct': 0},
            {'q': 'What is the first rule of electrical safety?', 'options': ['Wear gloves', 'Turn off power', 'Use tools', 'Check voltage'], 'correct': 1}
        ]
    }
    
    test_questions = questions.get(skill, [])
    return render_template('unique/skill_test.html', skill=skill, questions=test_questions)

@unique_bp.route('/submit-skill-test', methods=['POST'])
@login_required
def submit_skill_test():
    """Submit skill test results"""
    skill = request.form.get('skill')
    answers = request.form.getlist('answers')
    
    # Calculate score (simplified)
    score = random.randint(65, 95)  # Demo score
    
    # Create skill badge
    badge = SkillBadge(current_user.id, skill, score, datetime.now())
    skill_badges_db[badge.id] = badge
    
    # Update user skills if not already present
    if not hasattr(current_user, 'verified_skills'):
        current_user.verified_skills = []
    
    if skill not in current_user.verified_skills:
        current_user.verified_skills.append(skill)
    
    flash(f'Congratulations! You earned a {badge.badge_level} badge in {skill} with {score}% score!', 'success')
    return redirect(url_for('unique.skill_verification'))

@unique_bp.route('/emergency-services')
@login_required
def emergency_services():
    """Emergency services management"""
    if current_user.user_type not in ['worker', 'provider']:
        flash('Access denied', 'error')
        return redirect(url_for('index'))
    
    user_emergency_services = [es for es in emergency_services_db.values() 
                              if es.provider_id == current_user.id]
    
    return render_template('unique/emergency_services.html', 
                         emergency_services=user_emergency_services)

@unique_bp.route('/register-emergency-service', methods=['POST'])
@login_required
def register_emergency_service():
    """Register for emergency service provision"""
    service_type = request.form.get('service_type')
    response_time = int(request.form.get('response_time', 60))
    premium_rate = float(request.form.get('premium_rate', 0))
    
    emergency_service = EmergencyService(current_user.id, service_type, response_time, premium_rate)
    emergency_services_db[emergency_service.id] = emergency_service
    
    flash(f'Emergency service registered: {service_type}', 'success')
    return redirect(url_for('unique.emergency_services'))

@unique_bp.route('/local-coordinators')
def local_coordinators():
    """View local area coordinators"""
    coordinators = list(coordinators_db.values())
    return render_template('unique/local_coordinators.html', coordinators=coordinators)

@unique_bp.route('/apply-coordinator', methods=['POST'])
@login_required
def apply_coordinator():
    """Apply to become a local area coordinator"""
    area = request.form.get('area')
    specializations = request.form.getlist('specializations')
    
    coordinator = AreaCoordinator(current_user.id, area, specializations)
    coordinators_db[coordinator.id] = coordinator
    
    flash('Application submitted for area coordinator position', 'success')
    return redirect(url_for('unique.local_coordinators'))

@unique_bp.route('/api/enhanced-matching/<int:job_id>')
@login_required
def enhanced_job_matching(job_id):
    """Get enhanced job matching results"""
    job = jobs_db.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'})
    
    workers = [user for user in users_db.values() if user.user_type == 'worker']
    matches = []
    
    for worker in workers:
        match_score = calculate_unique_match_score(worker, job)
        if match_score > 30:  # Minimum threshold
            matches.append({
                'worker_id': worker.id,
                'username': worker.username,
                'match_score': round(match_score, 1),
                'skills': worker.skills or [],
                'rating': worker.rating or 0,
                'experience': worker.experience_years or 0,
                'verified_skills': getattr(worker, 'verified_skills', []),
                'certifications': len([c for c in certifications_db.values() if c.user_id == worker.id]),
                'emergency_available': len([es for es in emergency_services_db.values() if es.provider_id == worker.id]) > 0
            })
    
    # Sort by match score
    matches.sort(key=lambda x: x['match_score'], reverse=True)
    
    return jsonify({'matches': matches[:10]})  # Top 10 matches

# Initialize some sample data
def initialize_unique_features():
    """Initialize sample unique feature data"""
    # Sample certifications
    if len(certifications_db) == 0:
        cert1 = WorkerCertification(1, "Certified Plumber", "Mumbai Plumbing Association", datetime.now() + timedelta(days=365))
        cert2 = WorkerCertification(2, "Licensed Electrician", "Maharashtra Electrical Board", datetime.now() + timedelta(days=730))
        certifications_db[cert1.id] = cert1
        certifications_db[cert2.id] = cert2
    
    # Sample emergency services
    if len(emergency_services_db) == 0:
        es1 = EmergencyService(1, "Emergency Plumbing", 30, 150.0)
        es2 = EmergencyService(2, "Emergency Electrical", 45, 200.0)
        emergency_services_db[es1.id] = es1
        emergency_services_db[es2.id] = es2
    
    # Sample coordinators
    if len(coordinators_db) == 0:
        coord1 = AreaCoordinator(3, "South Mumbai", ["Plumbing", "Electrical"])
        coord2 = AreaCoordinator(4, "Pune Central", ["Carpentry", "Cleaning"])
        coordinators_db[coord1.id] = coord1
        coordinators_db[coord2.id] = coord2