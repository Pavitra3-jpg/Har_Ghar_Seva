from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime
from models import users_db, jobs_db, messages_db, create_message, get_conversations, get_messages_by_conversation

messages_bp = Blueprint('messages', __name__)

@messages_bp.route('/inbox')
@login_required
def inbox():
    """Display user's inbox with all conversations"""
    conversations = get_conversations(current_user.id)
    return render_template('messages/inbox.html', conversations=conversations)

@messages_bp.route('/conversation/<int:other_user_id>')
@login_required
def conversation(other_user_id):
    """Display conversation with another user"""
    other_user = users_db.get(other_user_id)
    if not other_user:
        flash('User not found.', 'error')
        return redirect(url_for('messages.inbox'))
    
    # Get or create conversation
    conversation_id = f"{min(current_user.id, other_user_id)}-{max(current_user.id, other_user_id)}"
    messages = get_messages_by_conversation(conversation_id)
    
    return render_template('messages/conversation.html', 
                         other_user=other_user, 
                         messages=messages,
                         conversation_id=conversation_id)

@messages_bp.route('/send_message', methods=['POST'])
@login_required
def send_message():
    """Send a new message"""
    recipient_id = int(request.form.get('recipient_id'))
    message_text = request.form.get('message', '').strip()
    job_id = request.form.get('job_id')  # Optional: link to specific job
    
    if not message_text:
        flash('Message cannot be empty.', 'error')
        return redirect(request.referrer or url_for('messages.inbox'))
    
    recipient = users_db.get(recipient_id)
    if not recipient:
        flash('Recipient not found.', 'error')
        return redirect(url_for('messages.inbox'))
    
    # Create message
    message = create_message(current_user.id, recipient_id, message_text, job_id)
    
    flash('Message sent successfully!', 'success')
    return redirect(url_for('messages.conversation', other_user_id=recipient_id))

@messages_bp.route('/api/messages/<conversation_id>')
@login_required
def api_get_messages(conversation_id):
    """API endpoint to get messages for real-time updates"""
    messages = get_messages_by_conversation(conversation_id)
    
    # Check if current user is part of this conversation
    user_ids = conversation_id.split('-')
    if str(current_user.id) not in user_ids:
        return jsonify({'error': 'Unauthorized'}), 403
    
    return jsonify({
        'messages': [{
            'id': msg.id,
            'sender_id': msg.sender_id,
            'sender_name': users_db.get(msg.sender_id).username if users_db.get(msg.sender_id) else 'Unknown',
            'message': msg.message,
            'created_at': msg.created_at.isoformat(),
            'is_read': msg.is_read
        } for msg in messages]
    })

@messages_bp.route('/api/send_message', methods=['POST'])
@login_required
def api_send_message():
    """API endpoint to send message via AJAX"""
    data = request.get_json()
    recipient_id = data.get('recipient_id')
    message_text = data.get('message', '').strip()
    job_id = data.get('job_id')
    
    if not message_text:
        return jsonify({'error': 'Message cannot be empty'}), 400
    
    recipient = users_db.get(recipient_id)
    if not recipient:
        return jsonify({'error': 'Recipient not found'}), 404
    
    message = create_message(current_user.id, recipient_id, message_text, job_id)
    
    return jsonify({
        'success': True,
        'message': {
            'id': message.id,
            'sender_id': message.sender_id,
            'sender_name': current_user.username,
            'message': message.message,
            'created_at': message.created_at.isoformat(),
            'is_read': message.is_read
        }
    })

@messages_bp.route('/api/mark_read', methods=['POST'])
@login_required
def api_mark_read():
    """Mark messages as read"""
    data = request.get_json()
    conversation_id = data.get('conversation_id')
    
    if not conversation_id:
        return jsonify({'error': 'Conversation ID required'}), 400
    
    # Mark all messages in conversation as read for current user
    messages = get_messages_by_conversation(conversation_id)
    for msg in messages:
        if msg.recipient_id == current_user.id:
            msg.is_read = True
    
    return jsonify({'success': True})

@messages_bp.route('/start_conversation/<int:user_id>')
@login_required
def start_conversation(user_id):
    """Start a new conversation with a user"""
    if user_id == current_user.id:
        flash('Cannot message yourself.', 'error')
        return redirect(url_for('messages.inbox'))
    
    other_user = users_db.get(user_id)
    if not other_user:
        flash('User not found.', 'error')
        return redirect(url_for('messages.inbox'))
    
    return redirect(url_for('messages.conversation', other_user_id=user_id))