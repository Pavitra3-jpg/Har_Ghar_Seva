from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models import users_db, jobs_db, messages_db, applications_db, get_unread_count
from datetime import datetime, timedelta

notifications_bp = Blueprint('notifications', __name__)

# In-memory notifications storage
notifications_db = {}

class Notification:
    def __init__(self, user_id, title, message, notification_type='info', action_url=None):
        self.id = len(notifications_db) + 1
        self.user_id = user_id
        self.title = title
        self.message = message
        self.type = notification_type  # 'info', 'success', 'warning', 'error'
        self.action_url = action_url
        self.is_read = False
        self.created_at = datetime.now()

def create_notification(user_id, title, message, notification_type='info', action_url=None):
    """Create a new notification"""
    notification = Notification(user_id, title, message, notification_type, action_url)
    notifications_db[notification.id] = notification
    return notification

@notifications_bp.route('/api/notifications')
@login_required
def get_notifications():
    """Get notifications for current user"""
    user_notifications = [
        {
            'id': notif.id,
            'title': notif.title,
            'message': notif.message,
            'type': notif.type,
            'action_url': notif.action_url,
            'is_read': notif.is_read,
            'time_ago': get_time_ago(notif.created_at)
        }
        for notif in notifications_db.values() 
        if notif.user_id == current_user.id
    ]
    
    # Sort by newest first
    user_notifications.sort(key=lambda x: notifications_db[x['id']].created_at, reverse=True)
    
    return jsonify({
        'notifications': user_notifications[:10],  # Return latest 10
        'unread_count': len([n for n in user_notifications if not n['is_read']])
    })

@notifications_bp.route('/api/mark_read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    """Mark notification as read"""
    notification = notifications_db.get(notification_id)
    if notification and notification.user_id == current_user.id:
        notification.is_read = True
        return jsonify({'success': True})
    return jsonify({'success': False})

@notifications_bp.route('/api/mark_all_read', methods=['POST'])
@login_required
def mark_all_notifications_read():
    """Mark all notifications as read for current user"""
    count = 0
    for notification in notifications_db.values():
        if notification.user_id == current_user.id and not notification.is_read:
            notification.is_read = True
            count += 1
    
    return jsonify({'success': True, 'marked_count': count})

def get_time_ago(timestamp):
    """Get human-readable time difference"""
    now = datetime.now()
    diff = now - timestamp
    
    if diff.seconds < 60:
        return "Just now"
    elif diff.seconds < 3600:
        minutes = diff.seconds // 60
        return f"{minutes}m ago"
    elif diff.seconds < 86400:
        hours = diff.seconds // 3600
        return f"{hours}h ago"
    elif diff.days == 1:
        return "Yesterday"
    elif diff.days < 7:
        return f"{diff.days}d ago"
    else:
        return timestamp.strftime('%b %d')

# Auto-generate notifications for various events
def notify_new_job_application(job_id, worker_id):
    """Notify job provider about new application"""
    job = jobs_db.get(job_id)
    worker = users_db.get(worker_id)
    
    if job and worker:
        create_notification(
            job.provider_id,
            "New Job Application",
            f"{worker.username} applied for your job '{job.title}'",
            'info',
            f'/jobs/details/{job_id}'
        )

def notify_application_status_change(application_id, status):
    """Notify worker about application status change"""
    app = applications_db.get(application_id)
    if app:
        job = jobs_db.get(app.job_id)
        status_colors = {'accepted': 'success', 'rejected': 'error', 'pending': 'warning'}
        
        create_notification(
            app.worker_id,
            f"Application {status.title()}",
            f"Your application for '{job.title}' has been {status}",
            status_colors.get(status, 'info'),
            f'/jobs/details/{job.id}'
        )

def notify_new_message(sender_id, recipient_id, job_id=None):
    """Notify user about new message"""
    sender = users_db.get(sender_id)
    job = jobs_db.get(job_id) if job_id else None
    
    if sender:
        job_context = f" about '{job.title}'" if job else ""
        create_notification(
            recipient_id,
            "New Message",
            f"{sender.username} sent you a message{job_context}",
            'info',
            f'/messages/conversation/{sender_id}'
        )

def notify_new_rating(rated_user_id, rater_id, job_id, rating):
    """Notify user about new rating"""
    rater = users_db.get(rater_id)
    job = jobs_db.get(job_id)
    
    if rater and job:
        stars = "⭐" * rating
        create_notification(
            rated_user_id,
            "New Rating Received",
            f"{rater.username} rated you {stars} ({rating}/5) for '{job.title}'",
            'success',
            f'/ratings/user/{rated_user_id}/reviews'
        )